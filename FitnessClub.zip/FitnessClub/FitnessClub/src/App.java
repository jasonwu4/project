import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.sql.ResultSet;
import java.sql.Date;
import java.util.Calendar;
import java.util.Scanner;
import java.sql.Time;


public class App {
    private static Connection conn;
    public static void main(String[] args) throws Exception {
        // JDBC & Database credentials
        String url = "jdbc:postgresql://localhost:5432/HealthFitnessClub";
        String user = "test";
        String password = "admin"; 

        try { // Load PostgreSQL JDBC Driver
            Class.forName("org.postgresql.Driver");
            // Connect to the database
            conn = DriverManager.getConnection(url, user, password);

            Scanner scanner = new Scanner(System.in);
            int userInput = -1;
            boolean loggedIn = false;
            while(!loggedIn && userInput != 0){
                printStartMenu();
                userInput = scanner.nextInt();

                //member login
                if(userInput == 1){
                    //take login info
                    scanner.nextLine();
                    System.out.println("Enter your email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter your password:");
                    String loginPassword = scanner.nextLine();

                    int id = login('M', email, loginPassword);
                    if(id != -1){
                        memberMenu(id);
                        loggedIn = true;
                    }else{
                        //if the account is not found
                        loggedIn = false;
                    }
                }else if(userInput ==2){
                    //take login info
                    scanner.nextLine();
                    System.out.println("Enter your email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter your password:");
                    String loginPassword = scanner.nextLine();

                    int id = login('T', email, loginPassword);
                    if(id != -1){
                        printTrainerMenu(id);
                        loggedIn = true;
                    }else{
                        //if the account is not found
                        loggedIn = false;
                    }
                }else if(userInput == 3){
                    //take login info
                    scanner.nextLine();
                    System.out.println("Enter your email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter your password:");
                    String loginPassword = scanner.nextLine();

                    int id = login('A', email, loginPassword);
                    if(id != -1){
                        printAdminMenu(id);
                        loggedIn = true;
                    }else{
                        //if the account is not found
                        loggedIn = false;
                    }
                
                }else if(userInput == 4){
                    scanner.nextLine();
                    //take new account info
                    System.out.println("Account Creation Page:");
                    System.out.println("Enter your email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter your password:");
                    String loginPassword = scanner.nextLine();
                    System.out.println("Enter your first name:");
                    String first_name = scanner.nextLine();
                    System.out.println("Enter your last name:");
                    String last_name = scanner.nextLine();
                    System.out.println("Enter your phone number:");
                    String phone_number = scanner.nextLine();
                    System.out.println("Enter your date of birth (yyyy-mm-dd):");
                    Date birth_date = Date.valueOf(scanner.nextLine());

                    createNewMember(email, loginPassword, first_name, last_name, phone_number, birth_date);
                }
            }   

            conn.close();
        }catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    //print Equipment menu
    public static void printEquipmentMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nEquipment Monitoring:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: See Equipment");
            System.out.println("Enter 2: Update Equipment");
            
            userInput = scanner.nextInt();

            if(userInput == 1){
                printEquipment();
            }else if(userInput == 2){
                printEquipment();
                System.out.println("\nWhich equipment do you want to update?");
                int equipment_id = scanner.nextInt();
                scanner.nextLine();
                System.out.println("What is the new status?");
                String status = scanner.nextLine();
                System.out.println("What is updated date? (yyyy-mm-dd)");
                Date date = Date.valueOf(scanner.nextLine());
                updateEquipment(equipment_id, status, date);
            }
        }while(userInput != 0);
    }

    //update equipment
    public static void updateEquipment(int equipment_id, String status, Date date){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE Equipment SET status='" + status + "', last_serviced='" + date +"' WHERE equipment_id =" + equipment_id;
            statement.executeUpdate(updateSQL);
            System.out.println("The equipment has been updated succesfully");

        }catch(SQLException e){
            e.printStackTrace();
            System.out.println("Unsuccesful update");
        };
    }

    //print all equipment
    public static void printEquipment(){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Equipment;";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("equipment_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("Last Serviced: " + rs.getDate("last_serviced") + "\n");

            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //print class schedule menu
    public static void printClassMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nManage Class Schedule:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: Add a class");
            System.out.println("Enter 2: Delete a class");
            System.out.println("Enter 3: Update a class");
            System.out.println("Enter 4: Show Classes");


            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("Which room booking do you want to add a class to?");
                printRoomBookings();
                int booking_id = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Which trainer do you want to lead the class? First Name:");
                String first_name = scanner.nextLine();
                System.out.println("Last Name");
                String last_name = scanner.nextLine();
                int trainer_id = getTrainerID(first_name, last_name);
                addClass(booking_id, trainer_id);
                
            }else if(userInput == 2){
                printRoomBookings();
                System.out.println("Which id do you want to delete");
                int class_id = scanner.nextInt();
                deleteClass(class_id);
            }else if(userInput == 3){
                printRoomBookings();
                System.out.println("Which id do you want to edit");
                int class_id = scanner.nextInt();

                System.out.println("Enter the updated details");
                scanner.nextLine();
                System.out.println("First Name of updated leader:");
                String first_name = scanner.nextLine();
                System.out.println("Last Name");
                String last_name = scanner.nextLine();
                int trainer_id = getTrainerID(first_name, last_name);
                editClass(class_id, trainer_id);

            }else if(userInput == 4){
                showOpenClasses();
            }

        }while(userInput != 0);
    } 

    //edit class
    public static void editClass(int class_id, int trainer_id){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE GroupFitnessClass SET trainer_id='" + trainer_id + "' WHERE class_id =" +class_id ;
            statement.executeUpdate(updateSQL);
            System.out.println("Your class has been updated succesfully");

        }catch(SQLException e){System.out.println("Unsuccesful update");};
    }

    //add a class
    public static void addClass(int booking_id, int trainer_id){
        String insertSQL = "INSERT INTO GroupFitnessClass(trainer_id,booking_id) VALUES (?, ?)";

        try{
            //set the variables for the query above
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setInt(1, trainer_id);
            preparedStatement.setInt(2, booking_id);
   
            preparedStatement.executeUpdate();
            System.out.println("Your new class has been added!\n");
        }
        catch(SQLException e){
           e.printStackTrace();
        }
    }

    //delete class
    public static void deleteClass(int class_id){
        try{
            //create delete query
            Statement statement = conn.createStatement();
            String deleteSQL = "DELETE FROM GroupFitnessClass WHERE class_id=" + class_id;
            statement.executeUpdate(deleteSQL);
            System.out.println("Class has been deleted.");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    //print room booking menu
    public static void printRoomManagement(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nManage Room Booking:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: Add a room booking");
            System.out.println("Enter 2: Delete a room booking");
            System.out.println("Enter 3: Change a room booking");
            System.out.println("Enter 4: Show bookings");


            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("Enter the name of the room you want to book");
                String room_name = scanner.nextLine();
                int room_id = getRoomID(room_name);
                
                System.out.println("What will the room be used for?\n");
                String purpose = scanner.nextLine();
                System.out.println("Enter the date of the timeslot (yyyy-mm-dd):");
                Date session_date = Date.valueOf(scanner.nextLine());
                System.out.println("Enter the start time of the timeslot (eg 04:30:00):");
                Time start_time = Time.valueOf(scanner.nextLine());
                System.out.println("Enter the end time of the timeslot (eg 05:30:00):");
                Time end_time = Time.valueOf(scanner.nextLine());
                addBooking(id, room_id, purpose, session_date, start_time, end_time);
    
            }else if(userInput == 2){
                printRoomBookings();
                System.out.println("Which id do you want to delete");
                deleteBooking(scanner.nextInt());
            }else if(userInput == 3){
                printRoomBookings();
                System.out.println("Which id do you want to edit");
                int booking_id = scanner.nextInt();

                System.out.println("Enter the updated details");
                scanner.nextLine();
                System.out.println("Enter the name of the room you want to book");
                String room_name = scanner.nextLine();
                int room_id = getRoomID(room_name);
                System.out.println("What will the room be used for?\n");
                String purpose = scanner.nextLine();
                System.out.println("Enter the date of the timeslot (yyyy-mm-dd):");
                Date session_date = Date.valueOf(scanner.nextLine());
                System.out.println("Enter the start time of the timeslot (eg 04:30:00):");
                Time start_time = Time.valueOf(scanner.nextLine());
                System.out.println("Enter the end time of the timeslot (eg 05:30:00):");
                Time end_time = Time.valueOf(scanner.nextLine());
                editRoomBooking(id, booking_id, room_id, purpose, session_date, start_time, end_time);

            }else if(userInput == 4){
                printRoomBookings();
            }

        }while(userInput != 0);
    } 

    //edit room booking
    public static void editRoomBooking(int id, int booking_id, int room_id, String purpose, Date session_date, Time start_time, Time end_time){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE RoomBooking SET room_id='" + room_id + "', purpose='"+ purpose + "', session_date='"+ session_date + "', start_time='" + start_time + "', end_time='" + end_time + "' WHERE booking_id =" + booking_id;
            statement.executeUpdate(updateSQL);
            System.out.println("Your booking has been updated succesfully");

        }catch(SQLException e){System.out.println("Unsuccesful update");};
    }

    //show all room bookings
    public static void printRoomBookings(){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM RoomBooking;";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("booking_id"));
                printBookingDetails(rs.getInt("booking_id"));

            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //delete room booking
    public static void deleteBooking(int booking_id){
        try{
            //create delete query
            Statement statement = conn.createStatement();
            String deleteSQL = "DELETE FROM RoomBooking WHERE booking_id=" + booking_id;
            statement.executeUpdate(deleteSQL);
            System.out.println("Booking has been deleted.");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //add new room booking
    public static void addBooking(int admin_id, int room_id, String purpose, Date session_date, Time start_time, Time end_time){
        String insertSQL = "INSERT INTO RoomBooking(admin_id, room_id, purpose, session_date,start_time,end_time) VALUES (?, ?, ?, ?,?,?)";

        try{
            //set the variables for the query above
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setInt(1, admin_id);
            preparedStatement.setInt(2, room_id);
            preparedStatement.setString(3, purpose);
            preparedStatement.setDate(4, session_date);
            preparedStatement.setTime(5, start_time);
            preparedStatement.setTime(6, end_time);

            preparedStatement.executeUpdate();
            System.out.println("Room has been booked!\n");
        }
        catch(SQLException e){
           e.printStackTrace();
        }
    }

    //print admin menu
    public static void printAdminMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nAdmin Menu:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: Room Booking Management");
            System.out.println("Enter 2: Equipment Maintenance Monitoring");
            System.out.println("Enter 3: Class Schedule Updating");
            System.out.println("Enter 4: Billing and Payment Processing");

            userInput = scanner.nextInt();

            if(userInput == 1){
                printRoomManagement(id);
            }else if(userInput == 2){
                printEquipmentMenu(id);
            }else if(userInput == 3){
                printClassMenu(id);
            }else if(userInput == 4){
                printBillingMenu(id);
            }

        }while(userInput != 0);
    }
    
    public static void printBillingMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nAdmin Menu:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: Create Bill");
            System.out.println("Enter 2: Process Payment");
            System.out.println("Enter 3: View all bills");

            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("First name on bill:");
                String first_name = scanner.nextLine();
                System.out.println("Last name on bill:");
                String last_name = scanner.nextLine();
                int member_id = getMemberID(first_name, last_name);
                System.out.println("Description (membership, private class, etc):");
                String description = scanner.nextLine();
                System.out.println("Amount:");
                float amount = scanner.nextFloat();
                scanner.nextLine();
                System.out.println("Due Date (yyyy-mm-dd):");
                Date date = Date.valueOf(scanner.nextLine());

                createBill(member_id, id, description, amount, date, false);
            }else if(userInput == 2){
                printBills();
                System.out.println("Which bill do you want to process a payment for?");
                int bill_id = scanner.nextInt();
                processPayment(bill_id);
            }else if(userInput == 3){
                printBills();
            }

        }while(userInput != 0);
    }

    public static void processPayment(int bill_id){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE Bill SET paid='true' WHERE billing_id =" +bill_id ;
            statement.executeUpdate(updateSQL);
            System.out.println("The bill has been paid");

        }catch(SQLException e){
            System.out.println("Unsuccesful update");
            e.printStackTrace();
        };
    }

    public static void createBill(int member_id, int admin_id, String description, float amount, Date due_date, boolean paid){
        String insertSQL = "INSERT INTO Bill(member_id, admin_id, description, amount, due_date, paid) VALUES (?, ?,?,?,?,?)";

        try{
            //set the variables for the query above
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setInt(1, member_id);
            preparedStatement.setInt(2, admin_id);
            preparedStatement.setString(3, description);
            preparedStatement.setFloat(4, amount);
            preparedStatement.setDate(5, due_date);
            preparedStatement.setBoolean(6, paid);

            preparedStatement.executeUpdate();
            System.out.println("Your new bill has been created!\n");
        }
        catch(SQLException e){
           e.printStackTrace();
        }
    }

    public static void printBills(){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Bill";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("billing_id"));
                System.out.println("Member: " + getMemberName(rs.getInt("member_id")));
                System.out.println("description: " + rs.getString("description"));
                System.out.println("Amount: "+ rs.getFloat("amount"));
                System.out.println("Due Date: " + rs.getDate("due_date"));
                System.out.println("Paid: " + rs.getBoolean("paid") + "\n");

            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //Prints start menu
    public static void printStartMenu(){
        System.out.println("Menu:");
        System.out.println("Enter 0: Exit");
        System.out.println("Enter 1: Login as Member");
        System.out.println("Enter 2: Login as Trainer");
        System.out.println("Enter 3: Login as Admin");
        System.out.println("Enter 4: Become a Member!");
    }

    //display trainer menu
    public static void printTrainerMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nTrainer Menu:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: See Schedule");
            System.out.println("Enter 2: Update Schedule");
            System.out.println("Enter 3: View Member Profile");
            userInput = scanner.nextInt();

            if(userInput == 1){
                System.out.println("Showing private sessions...\n");
                showTrainerPrivateSessions(id);

                System.out.println("Showing classes...\n");
                showTrainerClasses(id);

            }else if(userInput == 2){
                trainerUpdateMenu(id);
            }else if(userInput == 3){
                scanner.nextLine();
                System.out.println("Enter the first name you want to search for:");
                String first_name = scanner.nextLine();
                System.out.println("Enter the last name you want to search for:");
                String last_name = scanner.nextLine();
                int result = searchMember(first_name, last_name);
                if(result != -1){
                    printMemberInformation(id);
                }else{
                    System.out.println("Member not found.\n");
                }

            }

        }while(userInput != 0);
    }

    //search for member using name returns member_id
    public static int searchMember(String first_name, String last_name){
        try{
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Member WHERE first_name='" + first_name + "' AND last_name='"+ last_name +"';";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                return rs.getInt("member_id");
            }
        }catch(SQLException e){
           e.printStackTrace();
        }
        return -1;
    }

    //prints member informaition using id
    public static void printMemberInformation(int id){
        try{
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Member WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("First Name: " + rs.getString("first_name"));
                System.out.println("Last Name: " + rs.getString("last_name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone: " + rs.getString("phone"));
                showHealthStatistics(id);
            }
        }catch(SQLException e){
           e.printStackTrace();
        }
    }


    // add a new timeslot for trainer
    public static void addTimeslot(int id, Date session_date, Time start_time, Time end_time){
        String insertSQL = "INSERT INTO AvailiableTimeslot(trainer_id, session_date, start_time, end_time) VALUES (?, ?, ?, ?)";
        try{
            //set the variables for the query above
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setInt(1, id);
            preparedStatement.setDate(2, session_date);
            preparedStatement.setTime(3, start_time);
            preparedStatement.setTime(4, end_time);
            preparedStatement.executeUpdate();
            System.out.println("Your new timeslot has been added!\n");
        }
        catch(SQLException e){
           e.printStackTrace();
        }
    }

    //display trainer timeslots
    public static void displayTrainerTimeslots(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM AvailiableTimeslot WHERE trainer_id=" +id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("timeslot_id"));
                System.out.println("Date: " + rs.getDate("session_date"));
                System.out.println("Start Time: " + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time") + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //display trainer update menu
    public static void trainerUpdateMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nTrainer Menu:");
            System.out.println("Enter 0: Go Back");
            System.out.println("Enter 1: Add Timeslot");
            System.out.println("Enter 2: Delete Timeslot");
            System.out.println("Enter 3: Cancel Session");
            
            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("Enter the date of the timeslot (yyyy-mm-dd):");
                Date session_date = Date.valueOf(scanner.nextLine());
                System.out.println("Enter the start time of the timeslot (eg 04:30:00):");
                Time start_time = Time.valueOf(scanner.nextLine());
                System.out.println("Enter the end time of the timeslot (eg 05:30:00):");
                Time end_time = Time.valueOf(scanner.nextLine());
                addTimeslot(id, session_date, start_time, end_time);

            }else if(userInput == 2){
                System.out.println("Showing current timeslots");
                displayTrainerTimeslots(id);
                System.out.println("Which id do you want to delete? (enter -1 to stop)\n");
                scanner.nextLine();

                int input = scanner.nextInt();
                if(input != -1){
                    deleteTimeslot(input);
                }

            }else if(userInput == 3){
                System.out.println("Showing your scheduled sessions...\n");
                showTrainerPrivateSessions(id);
                System.out.println("Which id do you want to cancel?");
                int input = scanner.nextInt();
                cancelPrivateSession(input);
            }

        }while(userInput != 0);
    }
    
    //show all private sessions for a member
    public static void showTrainerPrivateSessions(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM PersonalTrainingSession WHERE trainer_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the private sessions
            while(rs.next()){
                System.out.println("id: " + rs.getInt("session_id"));
                int member_id = rs.getInt("member_id");
                System.out.println(getMemberName(member_id));
                System.out.println("Date: " + rs.getDate("session_date"));
                System.out.println("Start Time:" + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time") + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //create a new member
    public static void createNewMember(String email, String password, String first_name, String last_name, String phone_number, Date date_of_birth){
        String insertSQL = "INSERT INTO Member(email, password, first_name, last_name, phone, date_of_birth) VALUES (?, ?, ?, ?, ?, ?)";

        try{
            //set the variables for the query above
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, first_name);
            preparedStatement.setString(4, last_name);
            preparedStatement.setString(5, phone_number);
            preparedStatement.setDate(6, date_of_birth);

            preparedStatement.executeUpdate();
            System.out.println("Welcome to the club!\nPlease login with your new account.\n");
        }
        catch(SQLException e){
           // e.printStackTrace();

            System.out.println("Unsuccesful signup");
        }
        
    }

    //login
    public static int login(char type, String email, String password){
        String loginType = "";
        if(type == 'M'){
            loginType = "Member";
        }else if(type == 'T'){
            loginType = "Trainer";
        }else if(type == 'A'){
            loginType = "Admin";
        }

        String idType = "";
        if(type == 'M'){
            idType = "member_id";
        }else if(type == 'T'){
            idType = "trainer_id";
        }else if(type == 'A'){
            idType = "admin_id";
        }

        try{
            //create query
            String query = "SELECT * FROM " + loginType + " WHERE email = '" + email + "' AND password = '" + password + "';";
            Statement statement = conn.createStatement();
            statement.executeQuery(query); 
            ResultSet rs = statement.getResultSet();

            //check to see if there is a match
            if(rs.next()){
                System.out.println("You are now logged in as " + rs.getString("first_name") + " " + rs.getString("last_name") );
                return rs.getInt(idType);
            }else{
                System.out.println("No " + loginType + " found.");
                return -1;
            }

            
        }catch(SQLException e){
            e.printStackTrace();
        }
        return -1;
    }

    //prints the menu for the members
    public static void memberMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nMember Menu:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: Profile Management");
            System.out.println("Enter 2: Dashboard Display");
            System.out.println("Enter 3: Schedule Management");
            userInput = scanner.nextInt();

            if(userInput == 1){
                updateOptions(id);
            }else if(userInput == 2){
                dashboardDisplay(id);
            }else if(userInput == 3){
                memberScheduleDisplay(id);
            }

        }while(userInput != 0);
     
    }

    //displays the schedule management menu
    public static void memberScheduleDisplay(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nSchedule Management:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: See Scheduled Personal Sessions");
            System.out.println("Enter 2: See Scheduled Classes");
            System.out.println("Enter 3: Search for new Personal Session");
            System.out.println("Enter 4: Search for new Class");

            userInput = scanner.nextInt();

            if(userInput == 1){
                System.out.println("Showing your booked personal training sessions");
                showSchedule(id);

                System.out.println("Would you like to cancel one of your sessions? (0 = no, 1 = yes)");
                int cancel = scanner.nextInt();
                if(cancel == 1){
                    System.out.println("Enter the id of the session you want to delete");
                    int delete_id = scanner.nextInt();
                    cancelPrivateSession(delete_id);
                }
            }else if(userInput == 2){
                System.out.println("Showing your registered classes");
                showRegisteredClass(id);
                System.out.println("Would you like to leave one of your classes? (0 = no, 1 = yes)");
                int cancel = scanner.nextInt();
                if(cancel == 1){
                    System.out.println("Enter the id of the class you want to leave");
                    int delete_id = scanner.nextInt();
                    cancelClass(id, delete_id);
                }
            }else if(userInput == 3){
                System.out.print("Showing all open timeslots...");
                showOpenTimeslots();
                System.out.println("Would you like to book a session? (0 = no, 1 = yes)");
                int book = scanner.nextInt();
                if(book == 1){
                    System.out.println("Enter the id of the timeslot you want to book:\n");
                    int timeslot_id = scanner.nextInt();
                    bookNewSession(id, timeslot_id);
                }
            }else if (userInput==4){
                System.out.print("Showing all open classes...\n");
                showOpenClasses();
                System.out.println("Would you join a class? (0 = no, 1 = yes)");
                int input = scanner.nextInt();
                if(input == 1){
                    System.out.println("Enter the id of the class you want to join:\n");
                    int class_id = scanner.nextInt();
                    joinClass(id, class_id);
                }
            }
                

        }while(userInput != 0);
    }

    //shows all open classes a member can join
    public static void showOpenClasses(){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM GroupFitnessClass";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("class_id"));
                System.out.println("Trainer Name: " + getTrainerName(rs.getInt("trainer_id")));
                printBookingDetails(rs.getInt("booking_id"));

            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    
    //shows all classes lead by a trainer
    public static void showTrainerClasses(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM GroupFitnessClass WHERE trainer_id=" +id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("class_id"));
                printBookingDetails(rs.getInt("booking_id"));

            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public static void joinClass(int id, int class_id){
        String insertSQL = "INSERT INTO GroupClassMembers(class_id, member_id) VALUES (?, ?)";

        try{
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setInt(1, class_id);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
            System.out.println("You have registered for the class!\n");
            
        }catch(SQLException e){
            e.printStackTrace();
        }
    
    }

 

    // deletes a timeslot for a trainer
    public static void deleteTimeslot(int timeslot_id){
        try{
            //create delete query
            Statement statement = conn.createStatement();
            String deleteSQL = "DELETE FROM AvailiableTimeslot WHERE timeslot_id=" + timeslot_id;
            statement.executeUpdate(deleteSQL);
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public static void bookNewSession(int id, int timeslot_id){
        //create new training session
        String insertSQL = "INSERT INTO PersonalTrainingSession(member_id, trainer_id, session_date, start_time, end_time) VALUES (?, ?, ?, ?,?)";
    
            //get data 
            try{
                //create query
                Statement statement = conn.createStatement();
                String SQL = "SELECT * FROM AvailiableTimeslot WHERE timeslot_id=" + timeslot_id;
                statement.executeQuery(SQL);
                ResultSet rs = statement.getResultSet();
                
                while(rs.next()){
                    //set the variables for the query above
                    PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
                    preparedStatement.setInt(1, id);
                    preparedStatement.setInt(2, rs.getInt("trainer_id"));
                    preparedStatement.setDate(3, rs.getDate("session_date"));
                    preparedStatement.setTime(4, rs.getTime("start_time"));
                    preparedStatement.setTime(5, rs.getTime("end_time"));
                    preparedStatement.executeUpdate();
                    System.out.println("Your have booked the session\n");
                    deleteTimeslot(timeslot_id);
                }
            }catch(SQLException e){
                e.printStackTrace();
            }

            
        }
     

    //shows all availiable private sessions
    public static void showOpenTimeslots(){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM AvailiableTimeslot";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                System.out.println("id: " + rs.getInt("timeslot_id"));
                System.out.println("Trainer Name: " + getTrainerName(rs.getInt("trainer_id")));
                System.out.println("Date: " + rs.getDate("session_date"));
                System.out.println("Start Time: " + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time") + "\n");

            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //leave a group class
    public static void cancelClass(int id, int class_id){
        try{
            //create delete query
            Statement statement = conn.createStatement();
            String deleteSQL = "DELETE FROM GroupClassMembers WHERE member_id=" + id + " AND class_id=" +class_id;
            statement.executeUpdate(deleteSQL);
            System.out.println("You withdrew from the class.");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //cancel a private session
    public static void cancelPrivateSession(int session_id){
        try{
            //create delete query
            Statement statement = conn.createStatement();
            String deleteSQL = "DELETE FROM PersonalTrainingSession WHERE session_id=" + session_id;
            statement.executeUpdate(deleteSQL);
            System.out.println("Session has been canceled.");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //show all private sessions for a member
    public static void showSchedule(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM PersonalTrainingSession WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the private sessions
            while(rs.next()){
                System.out.println("id: " + rs.getInt("session_id"));
                int trainer_id = rs.getInt("trainer_id");
                System.out.println(getTrainerName(trainer_id));
                System.out.println("Date: " + rs.getDate("session_date"));
                System.out.println("Start Time:" + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time") + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //get the trainer name from an id
    public static String getTrainerName(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Trainer WHERE trainer_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                String first_name = rs.getString("first_name");
                String last_name = rs.getString("last_name");
                return first_name + " " + last_name;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return "error";
    }


    //get the member name from an id
    public static String getMemberName(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Member WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                String first_name = rs.getString("first_name");
                String last_name = rs.getString("last_name");
                return first_name + " " + last_name;
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return "error";
    }

    
    //get trainer id from name
    public static int getMemberID(String first_name, String last_name){
        try{
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Member WHERE first_name='" + first_name + "' AND last_name='"+ last_name +"';";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                return rs.getInt("member_id");
            }
        }catch(SQLException e){
           e.printStackTrace();
        }
        return -1;
    }



    //get trainer id from name
    public static int getTrainerID(String first_name, String last_name){
        try{
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Trainer WHERE first_name='" + first_name + "' AND last_name='"+ last_name +"';";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                return rs.getInt("trainer_id");
            }
        }catch(SQLException e){
           e.printStackTrace();
        }
        return -1;
    }

    //get room id from room name
    public static int getRoomID(String name){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Room WHERE name='" + name +"';";
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the private sessions
            while(rs.next()){
                return rs.getInt("room_id");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return -1;
    }

    //get room name from id
    public static String getRoomName(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Room WHERE room_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the private sessions
            while(rs.next()){
                return rs.getString("name");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return "error";
    }

    //uses a booking id to print all details
    public static void printBookingDetails(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM RoomBooking WHERE booking_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the private sessions
            while(rs.next()){
                System.out.println("Room:" + getRoomName(rs.getInt("room_id")));
                System.out.println("Purpose: " + rs.getString("purpose"));
                System.out.println("Date: " + rs.getDate("session_date"));
                System.out.println("Start Time:" + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time") + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        
    
    }

    //shows all classes registered by member_id
    public static void showRegisteredClass(int id){
        //show the registered classes
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM GroupClassMembers WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            while(rs.next()){
                int class_id = rs.getInt("class_id");
                System.out.println("id: " + class_id);
                //get each class
                try{
                    //create query
                    Statement statement2 = conn.createStatement();
                    String SQL2 = "SELECT * FROM GroupFitnessClass WHERE class_id=" + class_id;
                    statement2.executeQuery(SQL2);
                    ResultSet rs2 = statement2.getResultSet();
        
                    //print the private classes
                    while(rs2.next()){
                        System.out.println("Trainer: " + getTrainerName(rs2.getInt("trainer_id")));
                        printBookingDetails(rs2.getInt("booking_id"));
                    }
                }catch(SQLException e){
                    e.printStackTrace();
                }
            
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //display dashboard
    public static void dashboardDisplay(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nDashboard:");
            System.out.println("Enter 0: Exit");
            System.out.println("Enter 1: See Exercise Routines");
            System.out.println("Enter 2: See Fitness Achievements");
            System.out.println("Enter 3: See Health Statistics");
            userInput = scanner.nextInt();

            if(userInput == 1){
                System.out.println("Here are all your routines:");
                showExerciseRoutines(id);
            }else if(userInput == 2){
                System.out.println("Here are all your achievements:");
                showAchievements(id);
            }else if(userInput == 3){
                System.out.println("Health Statistics:");
                showHealthStatistics(id);
            }

        }while(userInput != 0);

    }

    //show member's exercise routines
    public static void showExerciseRoutines(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM ExerciseRoutines WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the exercise
            while(rs.next()){
                String name = rs.getString("name");
                int sets = rs.getInt("sets");
                int reps = rs.getInt("reps");
                System.out.println(name);
                System.out.println("Sets: " + sets);
                System.out.println("Reps: " + reps +"\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //shows users achievements
    public static void showAchievements(int id){
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Achievement WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the achievement
            while(rs.next()){
                String description = rs.getString("description");
                Date date = rs.getDate("date");
                System.out.println(description);
                System.out.println(date + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //show users health statistics
    public static void showHealthStatistics(int id){
        //get weight and height
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Metrics WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the data
            while(rs.next()){
                float weight = rs.getFloat("weight");
                float height = rs.getFloat("height");
                System.out.println("Height(cm): " + height);
                System.out.println("Weight(lbs): " + weight);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }

        //get statistics
        try{
            //create query
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Statistics WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the data
            while(rs.next()){
                float average_heartrate = rs.getFloat("average_heartrate");
                float average_calories_burned = rs.getFloat("average_calories_burned");
                System.out.println("Average Heartrate (bpm): " + average_heartrate);
                System.out.println("Average Calories Burned: " + average_calories_burned + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //print the menu for updating

    public static void updateOptions(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nUpdate Menu:");
            System.out.println("Enter 0: Go Back");
            System.out.println("Enter 1: Personal Information");
            System.out.println("Enter 2: Goals");
            System.out.println("Enter 3: Health Metrics");
            userInput = scanner.nextInt();

            if(userInput == 1){
                updateInfoMenu(id);
            }else if(userInput == 2){
                updateGoals(id);
            }else if(userInput == 3){
                updateMetricsMenu(id);
            }

        }while(userInput != 0);
    }

    //menu for updating metrics
    public static void updateMetricsMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nUpdate Metrics");
            System.out.println("Enter 0: Go Back");
            System.out.println("Enter 1: Height");
            System.out.println("Enter 2: Weight");
            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("What would you like to change your height(cm) to?");
                float height = scanner.nextFloat();
                updateHeight(id, height);
            }else if(userInput == 2){
                scanner.nextLine();
                System.out.println("What would you like to change your weight(lbs) to?");
                float weight = scanner.nextFloat();
                updateWeight(id, weight);
            }

        }while(userInput != 0);
    }
    
    //update height of member
    public static void updateHeight(int id, float height){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE Metrics SET height='" + height + "' WHERE member_id =" + id;
            statement.executeUpdate(updateSQL);
            System.out.println("Your height has been updated succesfully");

        }catch(SQLException e){System.out.println("Unsuccesful update");};
    }

    //update weight of member
    public static void updateWeight(int id, float weight){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE Metrics SET weight='" + weight + "' WHERE member_id =" + id;
            statement.executeUpdate(updateSQL);
            System.out.println("Your weight has been updated succesfully");

        }catch(SQLException e){System.out.println("Unsuccesful update");};
    }

    //menu for update selection
    public static void updateInfoMenu(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nUpdate Personal Information");
            System.out.println("Enter 0: Go Back");
            System.out.println("Enter 1: Email");
            System.out.println("Enter 2: Password");
            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("What would you like to change your email to?");
                String email = scanner.nextLine();
                updateEmail(id, email);
            }else if(userInput == 2){
                scanner.nextLine();
                System.out.println("What would you like to change your password to?");
                String password = scanner.nextLine();
                updatePassword(id, password);
            }

        }while(userInput != 0);
    }
    
    //update email of member
    public static void updateEmail(int id, String email){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE Member SET email='" + email + "' WHERE member_id =" + id;
            statement.executeUpdate(updateSQL);
            System.out.println("Your email has been updated succesfully");

        }catch(SQLException e){System.out.println("Unsuccesful update");};
    }

    //update password of member
    public static void updatePassword(int id, String password){
        try{
            //create update query
            Statement statement = conn.createStatement();
            String updateSQL = "UPDATE Member SET password='" + password + "' WHERE member_id =" + id;
            statement.executeUpdate(updateSQL);
            System.out.println("Your password has been updated succesfully");

        }catch(SQLException e){System.out.println("Unsuccesful update");};
    }

    //display goal management menu
    public static void updateGoals(int id){
        Scanner scanner = new Scanner(System.in);
        int userInput;

        do{
            System.out.println("\nHere is your list of goals:");
            showGoals(id);
            System.out.println("Enter 0: Go Back");
            System.out.println("Enter 1: Add Goal");
            System.out.println("Enter 2: Delete Goal");
            userInput = scanner.nextInt();

            if(userInput == 1){
                scanner.nextLine();
                System.out.println("What's your goal?");
                String description = scanner.nextLine();
                System.out.println("Whats your target date? (yyyy-mm-dd)");
                Date date_target = Date.valueOf(scanner.nextLine());

                //get todays date
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date_created = Date.valueOf(dateFormat.format(Calendar.getInstance().getTime()));

                addGoal(id, description, date_created, date_target);
            }else if(userInput == 2){
                scanner.nextLine();
                System.out.println("Which goal would you like to delete?");
                showGoals(id);
                int goal_id = scanner.nextInt();
                deleteGoal(id, goal_id);
            }

        }while(userInput != 0);
    }

    //add a goal for a member
    public static void addGoal(int id, String description, Date date_created, Date date_target){
        String insertSQL = "INSERT INTO Goal(member_id, description, date_created, date_target) VALUES (?, ?, ?, ?)";

        try{
            //set the variables for the query above
            PreparedStatement preparedStatement = conn.prepareStatement(insertSQL);
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, description);
            preparedStatement.setDate(3, date_created);
            preparedStatement.setDate(4, date_target);
            preparedStatement.executeUpdate();
            System.out.println("Your new goal has been added!\n");
        }
        catch(SQLException e){
           e.printStackTrace();
        }
    }

    //delete a members goal
    public static void deleteGoal(int id, int goal_id){
        try{
            //create delete query
            Statement statement = conn.createStatement();
            String deleteSQL = "DELETE FROM Goal WHERE goal_id=" + goal_id;
            statement.executeUpdate(deleteSQL);
            System.out.println("Goal has been deleted.");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //shows a members goal
    public static void showGoals(int id){
        try{
            //create query
            //get the goals
            Statement statement = conn.createStatement();
            String SQL = "SELECT * FROM Goal WHERE member_id=" + id;
            statement.executeQuery(SQL);
            ResultSet rs = statement.getResultSet();

            //print the goals
            while(rs.next()){
                int goal_id = rs.getInt("goal_id");
                String description = rs.getString("description");
                Date date_created = rs.getDate("date_created");
                Date date_target = rs.getDate("date_target");
                System.out.println("Goal id: " + goal_id + ": " + description);
                System.out.println("Date created: " + date_created);
                System.out.println("Target date: " + date_target + "\n");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
}
